import pandas as pd
import streamlit as st
from PIL import Image

#Printing project title
st.header('**Public Sentiment Analysis and Trading Platform**')

#Printing image
image = Image.open('reddit.PNG')
st.image(image, caption='Wallstreet/b' , width= 400, len = 300, channel = 'RGB')

#Importing from csv
sentiment_data = pd.read_csv('sentiment_data2.csv')
sentiment_data.drop(['sno'], axis=1, inplace = True)
sentiment_data.drop(['polarity_subjectivity','sentiment_score'] ,axis=1,  inplace = True)

#Printing DataFrame
st.subheader("**Following is the list of popular trending Reddit stocks in various sectors and there corresponding market sentiments & url links**")
st.write(sentiment_data)

#Asking question from user, which stock ?
st.subheader("**For which stock* you want to see the sentiments and corresponding prices ?**")
stock = st.text_input("")


#string_df = sentiment_data[sentiment_data['Name'].str.contains(stock)]
for index, row in sentiment_data.iterrows():
        if (row['Name'] == stock):
                st.write("Stock is {0} and Market sentimenets on the scale between 0 to 1 are as follows - negative {1} , neutral {2} and positive {3}. This is from the reddit posting - {4}  and url link  for this posting is {5}".format(row['Name'] , row['negative'],row['neutral'],row['postive'] ,row['title'],row['url']))
            
#st.write("stock is :" , stock 
# st.write("Market sentimenets of the stock {0} on the scale between 0 to 1 as follows - negative is {1} , neutral is {2} and positive is {3}. \n This is from the reddit posting - {4}  and url link  for this posting is {5}".format(row['Name'] , row['negative'],row['neutral'],row['postive']))# ,row['title'], row['url']))
# st.write("This is from the reddit posting - {4}  and url link  for this posting is {5}".format(row['title'], row['url']))
#st.write("Stock is {0} and Market sentimenets on the scale between 0 to 1 are negative {1} , neutral {2} and positive {3}. This is from the reddit posting - {4}  and url link  for this posting is {5}".format(string_df['Name'] , string_df['negative'],string_df['neutral'],string_df['postive'] ,string_df['title'], string_df['url']))#, row['title'])# , row['url'] , row['postive'] )





#Asking question from user, which sector ?
st.subheader("**Which 'sector' stocks you want to see the sentiments from and corresponding prices ?**")
sector1 = st.text_input("",key=1)


#Printing Image
if (sector1 == 'Finance'):
        image = Image.open('finance.jpg')
        st.image(image, caption='finane')
elif (sector1 == 'Technology'):
        image = Image.open('technology.jpg')
        st.image(image, caption='Technology')
elif (sector1 == 'Energy'):
        image = Image.open('energy.jpg')
        st.image(image, caption='energy')
elif (sector1 == 'Transportation'):
        image = Image.open('transportation.jpg')
        st.image(image, caption='transportation')
elif (sector1 == 'Consumer Services'):
        image = Image.open('consumer.jpg')
        st.image(image, caption='consumer')
elif (sector1 == 'Health Care'):
        image = Image.open('healthcare.jpg')
        st.image(image, caption='Health Care')
elif (sector1 == 'Capital Goods'):
        image = Image.open('capitalgood1.jpg')
        st.image(image, caption='Capital Goods')




#for index, row in sentiment_data.iterrows():
sector_df = sentiment_data[sentiment_data['sector'] == sector1]
st.write(sector_df)



#Asking question from user, postive sentiment range ?

st.subheader("**Do you want to see 'positive' or 'negative' sentiments or 'polarity' ?** ")
emotion = st.text_input("",key=2)

st.subheader("**For which range of sentiments, you want to see the stocks ?.** ")
positive = st.slider('', 0.0, 1.0, (0.0, 1.0))
min_positive = positive[0]
max_positive = positive[1]



if (emotion == 'positive'):
        positive_df = sentiment_data[(sentiment_data['postive'] > min_positive) & (sentiment_data['postive'] < max_positive)]
        positive_df.drop(['compound', 'negative' , 'neutral', 'polarity','subjectivity'] , axis = 1 , inplace = True)
        st.write(positive_df)
elif (emotion == 'negative'):
        negative_df = sentiment_data[(sentiment_data['negative'] > min_positive) & (sentiment_data['negative'] < max_positive)]
        negative_df.drop(['compound', 'postive' , 'neutral', 'polarity','subjectivity'] , axis = 1 , inplace = True)
        st.write(negative_df)

elif (emotion == 'polarity'):
        polarity_df = sentiment_data[(sentiment_data['polarity'] > min_positive) & (sentiment_data['polarity'] < max_positive)]
        polarity_df.drop(['negative' ,'compound', 'postive' , 'neutral','subjectivity'] , axis = 1 , inplace = True)
        st.write(polarity_df)



import numpy as np
st.bar_chart(sector_df['polarity'])




#*************************************************** 








# st.(polarity_df.plot( x= stock , y = 'polarity', rot=45))
# chart_polarity = sector_df['polarity']
# #st.write(chart_polarity)